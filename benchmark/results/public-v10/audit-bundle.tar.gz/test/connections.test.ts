import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { createAuthProvider } from '../src/auth.js';
import { createUpstreams } from '../src/upstreams.js';
import type { GatewayConfig } from '../src/types.js';

test('stdio upstream is lazy, reusable, paginated-compatible, and returns MCP result data', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'local-mcp-connections-'));
  const config: GatewayConfig = { version: 1, servers: { issues: { command: process.execPath, args: [resolve('examples/demo-server.mjs'), 'issues'] } } };
  const upstreams = createUpstreams(config, join(dir, 'config.json'));
  try {
    const tools = await upstreams.listTools();
    assert.equal(tools.length, 1);
    assert.equal(tools[0]?.name, 'list_issues');
    assert.equal(upstreams.getErrors()['issues'], undefined);
    const result = await upstreams.callTool('issues', 'list_issues', { state: 'open' }) as { content: Array<{ text: string }> };
    assert.match(result.content[0]?.text ?? '', /issue-1/);
    // Cached tool listing must preserve the same usable long-lived connection.
    assert.equal(await upstreams.listTools(), tools, 'cached aggregate catalogue keeps a stable identity');
  } finally {
    await upstreams.close();
    await rm(dir, { recursive: true, force: true });
  }
});

test('upstream failures are sanitized and do not reveal transport details', async () => {
  const upstreams = createUpstreams({ version: 1, servers: { secret: { command: '/no/such/private-command-123' } } }, '/tmp/local-mcp-test/config.json');
  try {
    assert.deepEqual(await upstreams.listTools(), []);
    assert.match(upstreams.getErrors().secret ?? '', /stdio upstream/);
    assert.doesNotMatch(upstreams.getErrors().secret ?? '', /private-command-123/);
  } finally { await upstreams.close(); }
});

test('OAuth state is durable with restricted permissions and bound to endpoint and config path', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'local-mcp-auth-'));
  const configPath = join(dir, 'config.json');
  try {
    const config = { url: 'https://one.example/mcp', oauth: { clientId: 'gateway-client' } } as const;
    const provider = createAuthProvider('remote', config, configPath);
    const state = await provider.state?.();
    assert.ok(state);
    assert.equal(await provider.state?.(), state);
    await provider.saveTokens({ access_token: 'test-access', token_type: 'Bearer', refresh_token: 'test-refresh' });
    const authDir = join(dir, '.local-mcp-auth');
    const files = await import('node:fs/promises').then(fs => fs.readdir(authDir));
    assert.equal(files.length, 1);
    const mode = (await stat(join(authDir, files[0]!))).mode & 0o777;
    assert.equal(mode, 0o600);
    assert.equal((await createAuthProvider('remote', config, configPath).tokens())?.access_token, 'test-access');
    assert.equal(await createAuthProvider('remote', { ...config, url: 'https://two.example/mcp' }, configPath).tokens(), undefined);
    assert.equal(await createAuthProvider('remote', config, join(dir, 'other', 'config.json')).tokens(), undefined);
  } finally { await rm(dir, { recursive: true, force: true }); }
});
